package com.priordesign.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Proximityactivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "Proximityactivity";

    private SensorManager sensorManager;
    private Sensor mProxi;

    TextView proximity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proximityactivity);

        proximity = (TextView) findViewById(R.id.proximity);

        Log.d(TAG, "onCreate: Initializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        /*Proximity Sensor*/
        mProxi = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        if(mProxi!= null){
            sensorManager.registerListener(Proximityactivity.this, mProxi, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Proximity listener");
        } else {
            proximity.setText("Proximity Not Supported");
        }
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d(TAG, "onSensorChanged: X: " + event.values[0]);

        proximity.setText("Proximity: " + event.values[0] + " cm");
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}