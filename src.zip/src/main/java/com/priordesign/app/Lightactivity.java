package com.priordesign.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Lightactivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "Lightactivity";

    private SensorManager sensorManager;

    private Sensor mLight;

    TextView light;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lightactivity);

        light = (TextView) findViewById(R.id.light);

        Log.d(TAG, "onCreate: Initializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        /*Light Sensor*/
        mLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if(mLight!= null){
            sensorManager.registerListener(Lightactivity.this, mLight, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Light listener");
        } else {
            light.setText("Light Not Supported");
        }


    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d(TAG, "onSensorChanged: X: " + event.values[0]);

        light.setText("Light: " + event.values[0] + " lx");
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}