package com.priordesign.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Magnoactivity extends AppCompatActivity implements SensorEventListener{

    private static final String TAG = "Magnoactivity";

    private SensorManager sensorManager;
    private Sensor mMagno;

    TextView xMagnoValue, yMagnoValue, zMagnoValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_magnoactivity);

        xMagnoValue = (TextView) findViewById(R.id.xMagnoValue);
        yMagnoValue = (TextView) findViewById(R.id.yMagnoValue);
        zMagnoValue = (TextView) findViewById(R.id.zMagnoValue);

        Log.d(TAG, "onCreate: Initializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        /*Magnetometer*/
        mMagno = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if(mMagno!= null){
            sensorManager.registerListener(Magnoactivity.this, mMagno, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Magnetometer listener");
        } else {
            xMagnoValue.setText("Magnetometer Not Supported");
            yMagnoValue.setText("Magnetometer Not Supported");
            zMagnoValue.setText("Magnetometer Not Supported");
        }
    }
    public void onSensorChanged(SensorEvent event) {

        Log.d(TAG, "onSensorChanged: X: " + event.values[0] + "Y: " + event.values[1] + "Z: " + event.values[2]);
        xMagnoValue.setText("X: " + event.values[0] + " μT");
        yMagnoValue.setText("Y: " + event.values[1] + " μT");
        zMagnoValue.setText("Z: " + event.values[2] + " μT");
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}