package com.priordesign.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FirstActivity extends AppCompatActivity {

    private Button Applicationbtn;

    private Button Sensorsbtn;

    private Button Refbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        Applicationbtn = (Button) findViewById(R.id.textbtn);

        Sensorsbtn = (Button) findViewById(R.id.sensorsbtn);

        Refbtn = (Button) findViewById(R.id.References);

        /*Accelerometerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openaccelerometer();
            }
        });

        Gyrobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opengyroscope();
            }
        });

        Magnetometerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openmagnetometer(); }
        });

        Lightbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openlightsensor();}
        });

        Proxibtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openproximity();
            }
        });

        Refbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openreferences();
            }
        });*/

        Applicationbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentextrecognition();
            }
        });

        Sensorsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opensensors();
            }
        });

        Refbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openreferences();
            }
        });


        //xValue = (TextView) findViewById(R.id.xValue);
        //yValue = (TextView) findViewById(R.id.yValue);
        //zValue = (TextView) findViewById(R.id.zValue);

        //Log.d(TAG, "onCreate: Initializing Sensor Services");
        //sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        //accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        //sensorManager.registerListener(MainActivity.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        //Log.d(TAG, "onCreate: Registered accelerometer listener");

    }


    //@Override
    /*public void onSensorChanged(SensorEvent event) {
        Log.d(TAG, "onSensorChanged: X: " + event.values[0] + "Y: " + event.values[1] + "Z: " + event.values[2]);

        xValue.setText("xValue: " + event.values[0]);
        yValue.setText("yValue: " + event.values[1]);
        zValue.setText("zValue: " + event.values[2]);
    }*/


    /*@Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }*/


   /* public void openaccelerometer() {
        Intent intent = new Intent(this, Acceleroactivity.class);
        startActivity(intent);
    }

    public void opengyroscope() {
        Intent intent = new Intent(this, Gyroactivity.class);
        startActivity(intent);
    }

    public void openmagnetometer() {
        Intent intent = new Intent(this, Magnoactivity.class);
        startActivity(intent);
    }

    public void openlightsensor() {
        Intent intent = new Intent(this, Lightactivity.class);
        startActivity(intent);
    }

    public void openproximity() {
        Intent intent = new Intent(this, Proximityactivity.class);
        startActivity(intent);
    }

    public void openreferences() {
        Intent intent = new Intent(this, Referenceactivity.class);
        startActivity(intent);
    }*/

    public void opentextrecognition() {
        Intent intent = new Intent(this, Textrecogactivity.class);
        startActivity(intent);
    }

    public void opensensors() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openreferences() {
        Intent intent = new Intent(this, Referenceactivity.class);
        startActivity(intent);
    }
}
